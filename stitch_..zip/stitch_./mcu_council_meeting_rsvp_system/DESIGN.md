---
name: MCU Council Meeting RSVP System
colors:
  surface: '#fef7ff'
  surface-dim: '#ded7e4'
  surface-bright: '#fef7ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f1fe'
  surface-container: '#f3ebf8'
  surface-container-high: '#ede5f2'
  surface-container-highest: '#e7e0ed'
  on-surface: '#1d1a23'
  on-surface-variant: '#4d444e'
  inverse-surface: '#322f38'
  inverse-on-surface: '#f6eefb'
  outline: '#7e747f'
  outline-variant: '#cfc3cf'
  surface-tint: '#7a4c8d'
  primary: '#340547'
  on-primary: '#ffffff'
  primary-container: '#4b1f5e'
  on-primary-container: '#bc88ce'
  inverse-primary: '#eab3fd'
  secondary: '#794c91'
  on-secondary: '#ffffff'
  secondary-container: '#e5b0fe'
  on-secondary-container: '#6a3e82'
  tertiary: '#765a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#caa74d'
  on-tertiary-container: '#513d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f8d8ff'
  primary-fixed-dim: '#eab3fd'
  on-primary-fixed: '#310245'
  on-primary-fixed-variant: '#613474'
  secondary-fixed: '#f5d9ff'
  secondary-fixed-dim: '#e7b4ff'
  on-secondary-fixed: '#300148'
  on-secondary-fixed-variant: '#5f3477'
  tertiary-fixed: '#ffdf95'
  tertiary-fixed-dim: '#e8c265'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#594400'
  background: '#fef7ff'
  on-background: '#1d1a23'
  surface-variant: '#e7e0ed'
typography:
  display-lg:
    fontFamily: Noto Serif
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.875rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Noto Serif
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Serif
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2.125rem
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Noto Serif
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  headline-sm:
    fontFamily: Noto Serif
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
  body-lg:
    fontFamily: Source Sans 3
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Source Sans 3
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Source Sans 3
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  label-lg:
    fontFamily: Source Sans 3
    fontSize: 1rem
    fontWeight: '600'
    lineHeight: 1.5rem
  label-md:
    fontFamily: Source Sans 3
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-sm:
    fontFamily: Source Sans 3
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  container-max: 75rem
  gutter-mobile: 1rem
  gutter-desktop: 1.5rem
---

## Brand & Style

The design system embodies the stately gravitas, historical prestige, and ecclesiastical authority of Mahachulalongkornrajavidyalaya University (MCU). Crafted specifically for university council members, venerable monastic elders, senior executives, and academic dignitaries, the interface delivers an experience of structured decorum, academic distinction, and effortless administrative clarity.

The visual style blends **Corporate Elegance** with **Regal Heritage Minimalism**:
- **Dignified Authority:** Grounded in deep imperial purple and traditional gold trim, evoking veneration and institutional weight.
- **Formal Clarity:** A disciplined, clutter-free administrative environment where meeting agendas, RSVP states, dietary preferences, and proxy appointments can be reviewed without cognitive friction.
- **Ceremonial Polish:** Clean, structured cards, precise micro-borders, and gilded accents that present digital council affairs with the reverence of physical parchment and university seal documentation.
- **Accessible Respect:** Generous hit targets and high-contrast typographic balance designed to accommodate senior council members and monastic elders across handheld tablets and mobile screens.

## Colors

The palette establishes an unmistakable sense of institutional nobility, anchored by royal university purple and accented with heritage monastic gold.

### Primary & Brand Layers
- **Primary Deep Royal Purple (`#4B1F5E`):** Represents institutional authority, council sovereignty, and supreme governance. Applied to dominant mastheads, primary confirmative actions, active states, and structural badges.
- **Secondary Vibrant Purple (`#6B3F83`):** Provides depth and interactive clarity for secondary hover accents, active tab borders, and elevated interactive states.
- **Accent Heritage Gold (`#C8A54B`):** Bestows academic honor, formal recognition, and distinction. Used for council crests, official session tags, ceremonial ribbons, and high-priority notices.
- **Gold Light (`#F9F5EA`):** Gentle ivory-gold wash for highlighted callouts, quorum notices, and council chairman annotations.
- **Gold Border (`#E0CA82`):** Delicately frames premium notices, executive badges, and active gold states.

### Surfaces & Neutral Architecture
- **Surface Base (`#F8F9FA`):** Modern institutional backdrop providing warm, comfortable readability across high-luminance screens.
- **Surface Card (`#FFFFFF`):** High-clarity white containers presenting meeting dossiers, agenda cards, and attendee rosters.
- **Text Primary (`#1E1B24`):** High-legibility deep obsidian purple-gray for titles, formal body text, and agenda headers.
- **Text Secondary (`#5E5868`):** Subdued slate violet for meeting metadata, timestamps, council committee designations, and helper text.
- **Border / Dividers (`#E7E4EC`):** Whisper-soft purple-tinted gray boundaries separating discrete agenda sections and form fields cleanly without visual noise.

### Council Governance Statuses
- **Status Success / Attending (`#15803D`):** Unambiguous verification for accepted attendance and finalized quorum confirmations.
- **Status Warning / Pending Action (`#B45309`):** Indicates pending agenda reviews, provisional RSVPs, or awaiting delegate proxies.
- **Status Danger / Regrets & Absence (`#B91C1C`):** Respectful crimson indicator for formal notice of absence or quorum shortages.
- **Status Info / Council Announcement (`#1D4ED8`):** Reserved for technical instructions, live broadcast links, and annex downloads.

## Typography

The typographic hierarchy projects solemn academic dignity while guaranteeing crisp legibility in both Thai and Latin scripts.

### Font System & Font-Stack Strategy
- **Headlines (`Noto Serif`):** Delivers stately presence, literary depth, and institutional gravitas for council meeting titles, formal decrees, and section demarcations. When rendering Thai headings, browsers fall back gracefully through `'Sarabun', 'Noto Sans Thai', serif` with matching metrics.
- **Body & Controls (`Source Sans 3`):** Clean, utilitarian, and dependable. Provides open apertures and generous x-heights to support high scan-speed across complex agendas, proxy lists, and responsive forms. For Thai text, the font smoothly chains into `'Sarabun', 'Noto Sans Thai', sans-serif`.

### Hierarchy Application Rules
- **Display & Large Headlines:** Reserved strictly for council session banners (e.g., การประชุมสภามหาวิทยาลัย ครั้งที่ ๔/๒๕๖๗) and major status summaries.
- **Medium & Small Headlines:** Applied to card headers, meeting agenda item numbers, and panel group headers.
- **Body Text:** Standardized on `body-md` (16px) with an intentional 1.5 line-height ratio to ensure comfortable readability of formal academic titles, monastic ranks (สมณศักดิ์), and procedural notes.
- **Labels & Badges:** Use semibold weights with slight tracking expansion to maintain distinct visual clarity on high-density RSVP summary grids.

## Layout & Spacing

The layout adopts a disciplined **Fixed Grid within Max-Width Shell** architecture, framing information with architectural balance and generous margins.

### Grid Geometry & Responsive Reflow
- **Desktop (1024px and above):** Centered max-width shell of `75rem` (1200px) utilizing a 12-column grid with `1.5rem` (24px) gutters. The layout typically resolves into an asymmetrical 8-column primary work surface (Meeting Details, RSVP Form, Agenda Files) and a 4-column reference drawer (Quorum Summary, Council Member Profile, Venue Map).
- **Tablet (768px – 1023px):** 8-column layout with `1.25rem` (20px) gutters. The reference drawer docks smoothly beneath primary attendance controls.
- **Mobile (Below 768px):** Single-column stacked stream with `1rem` (16px) gutters and screen margins. Sticky bottom action bar ensures critical RSVP decision buttons remain reachable within the one-handed thumb zone.

### Spacing Cadence
Spacing scales across an 8-point base increment:
- Micro-spacing (`0.25rem`, `0.5rem`) controls internal badge padding, button icon offsets, and input field boundaries.
- Content groupings (`1rem`, `1.5rem`) separate individual agenda rows and form sections.
- Structural breathing room (`2rem`, `3rem`) gives the interface an unhurried, ceremonial poise appropriate for council proceedings.

## Elevation & Depth

The design system rejects aggressive 3D illusions and heavy dropshadows in favor of **Crisp Architectural Elevation** combining delicate borders with soft, tinted ambient penumbras.

### Depth Hierarchy
- **Level 0 (Flat / Canvas):** Applied to the main `#F8F9FA` canvas background. No shadow.
- **Level 1 (Card & Section Containers):** Standard content modules on white cards (`#FFFFFF`). Defined by a structural 1px border of `#E7E4EC` accompanied by an ambient purple-tinted shadow:
  `box-shadow: 0 1px 3px 0 rgba(75, 31, 94, 0.04), 0 1px 2px -1px rgba(75, 31, 94, 0.02);`
- **Level 2 (Hover & Active Selection Cards):** RSVP choice cards, focused agenda modules, and active delegates.
  `box-shadow: 0 4px 6px -1px rgba(75, 31, 94, 0.07), 0 2px 4px -2px rgba(75, 31, 94, 0.05);`
  Border intensifies subtly to `#C8A54B` (Gold) or `#6B3F83` (Secondary Purple).
- **Level 3 (Sticky Headers & Overlays):** Sticky attendance status bars, modal dialogs (e.g., Delegate Proxy Form), and popovers.
  `box-shadow: 0 12px 24px -4px rgba(75, 31, 94, 0.10), 0 4px 8px -2px rgba(75, 31, 94, 0.04);`
- **Gold Accent Accentuation:** High-significance cards (such as the Official Convocation Notice from the Council President) incorporate a 3px solid top border of Accent Heritage Gold (`#C8A54B`) with an ambient gold glow aura (`0 0 12px rgba(200, 165, 75, 0.15)`).

## Shapes

The design system maintains a **Soft Architectural Roundedness (`1`)**, communicating formal institutional governance through grounded, crisp lines softened by gentle 4px–12px radii.

### Curvature Tokens
- **Base Components (`rounded` = 4px / `0.25rem`):** Applied to input fields, list item hover states, checkboxes, radio button frames, and small badges.
- **Cards & Structural Containers (`rounded-lg` = 8px / `0.5rem`):** Applied to agenda cards, council dossier panels, modal shells, and primary action buttons.
- **Prominent Modules & Popups (`rounded-xl` = 12px / `0.75rem`):** Applied to major attendance banners, ceremonial invitations, and profile cards.
- **Badges & Avatars (`rounded-full`):** Reserved exclusively for monastic and executive portrait photos, circular step indicators, and quorum pill tags.

## Components

### 1. Buttons
- **Primary Council Action (Attend / Confirm):** Background `#4B1F5E`, text `#FFFFFF`, border none, `rounded-lg` (8px). On hover, background shifts to `#6B3F83`. Focus ring shows a distinct 2px offset in `#C8A54B` (Heritage Gold). Height: 44px (desktop) / 48px (mobile) to guarantee dignified, error-free tapping.
- **Secondary Action (Delegate Proxy / Download Agenda):** Background `#FFFFFF`, text `#4B1F5E`, 1px border `#4B1F5E`. On hover: `#F9F5EA` background with `#C8A54B` border.
- **Decline / Regrets Button:** Background `#FFFFFF`, text `#B91C1C`, 1px border `#B91C1C`. On hover: subtle `#FEF2F2` crimson wash.

### 2. RSVP Selection Cards
- Specialized radio-card modules enabling council members to choose attendance modes (e.g., เข้าร่วมประชุม ณ สถานที่ / เข้าร่วมประชุมผ่านสื่ออิเล็กทรอนิกส์ / ไม่สามารถเข้าร่วม).
- **Default State:** White background, 1px border `#E7E4EC`, 8px rounded corners.
- **Selected State:** Light Gold wash background `#F9F5EA`, crisp 2px border `#C8A54B`, text `#1E1B24`, and an active gold radio indicator containing a checkmark.

### 3. Badges & Chips
- **Quorum & Role Badges:** 4px vertical padding, 10px horizontal padding, `rounded-sm` (4px).
  - *Council President / Officer:* Background `#F9F5EA`, border 1px `#E0CA82`, text `#4B1F5E`, font semibold.
  - *Confirmed Attendance:* Background `#DCFCE7`, text `#15803D`, border 1px `#86EFAC`.
  - *Apologies / Absent:* Background `#FEE2E2`, text `#B91C1C`, border 1px `#FCA5A5`.
  - *Pending Decision:* Background `#FEF3C7`, text `#B45309`, border 1px `#FDE68A`.

### 4. Form Controls & Inputs
- **Text & Textarea Fields:** 1px border `#E7E4EC`, background `#FFFFFF`, text `#1E1B24`, placeholder `#5E5868`. Padding: 10px 14px. Focus state: border `#4B1F5E`, 3px soft outer ring of `rgba(75, 31, 94, 0.12)`.
- **Special Dietary & Monastic Needs (Radio / Checkbox):** Strict 20px x 20px hit targets with 4px border radius for checkboxes and circular for radios. Active fill `#4B1F5E`. Accommodates options such as ภัตตาหารเจ (Vegetarian), มังสวิรัติ, ฮาลาล (Halal), or จัดเตรียมภัตตาหารถวายพระเถระ (Monastic meal protocols).

### 5. Agenda & Document Cards
- Structured list rows containing agenda sequence badges (วาระที่ ๑, วาระที่ ๒), title in `Noto Serif`, accompanying PDF badges, and download triggers. Divided cleanly with 1px `#E7E4EC` dividers and hovering to a subtle `#F8F9FA` row highlight.

### 6. Quorum Progress Bar
- Displays official quorum tracking (จำนวนองค์ประชุม). A 10px high structural bar with `#E7E4EC` track and `#C8A54B` fill, transitioning to `#15803D` once statutory quorum count is officially reached.